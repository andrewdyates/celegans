datacache <- new.env(hash=TRUE, parent=emptyenv())

celeganscerefseq <- function() showQCData("celeganscerefseq", datacache)
celeganscerefseq_dbconn <- function() dbconn(datacache)
celeganscerefseq_dbfile <- function() dbfile(datacache)
celeganscerefseq_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
celeganscerefseq_dbInfo <- function() dbInfo(datacache)

celeganscerefseqORGANISM <- "Caenorhabditis elegans"

.onLoad <- function(libname, pkgname)
{
    require("methods", quietly=TRUE)
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "celeganscerefseq.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    txdb <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"ChipDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, txdb, envir=ns)
    namespaceExport(ns, dbNewname)
        
    ## Create the AnnObj instances
    ann_objs <- createAnnObjs.SchemaChoice("WORMCHIP_DB", "celeganscerefseq", "chip celeganscerefseq", dbconn, datacache)
    mergeToNamespaceAndExport(ann_objs, pkgname)
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("celeganscerefseq.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(celeganscerefseq_dbconn())
}

